#include <Arduino.h>

//#define __DEBUG__

#define   PIN_EN          D7
#define   ENABLE_MOTOR    digitalWrite(PIN_EN, LOW)
#define   DISABLE_MOTOR   digitalWrite(PIN_EN, HIGH)

#define   PIN_STEP        D1
#define   PIN_STEP_SET    digitalWrite(PIN_STEP, HIGH)
#define   PIN_STEP_CLR    digitalWrite(PIN_STEP, LOW)
#define   PIN_STEP_CHK    digitalRead(PIN_STEP) == LOW

#define   PIN_DIR         D2
#define   PIN_DIR_SET     digitalWrite(PIN_DIR, HIGH)
#define   PIN_DIR_CLR     digitalWrite(PIN_DIR, LOW)
#define   DIR_FWD_SET     PIN_DIR_CLR
#define   DIR_BACK_SET    PIN_DIR_SET

#define   PIN_FWD         D5
#define   PIN_FWD_CHK     digitalRead(PIN_FWD) == LOW

#define   PIN_BACK        D6
#define   PIN_BACK_CHK    digitalRead(PIN_BACK) == LOW

#define   PIN_POT         A0

#define   SYS_TICK            3
#define   MAX_TICK            5000
#define   BTN_TICK            1000

#define   FLAG_MOVE_FWD       0b10000000
#define   FLAG_MOVE_FWD_SET   DIR_FWD_SET;gv_tkSTEP=0;gv_ucFLAG|=FLAG_MOVE_FWD
#define   FLAG_MOVE_FWD_CLR   gv_ucFLAG&=~FLAG_MOVE_FWD

#define   FLAG_MOVE_BACK      0b01000000
#define   FLAG_MOVE_BACK_SET  DIR_BACK_SET;gv_tkSTEP=0;gv_ucFLAG|=FLAG_MOVE_BACK
#define   FLAG_MOVE_BACK_CLR  gv_ucFLAG&=~FLAG_MOVE_BACK

#define   FLAG_MOVING_CLR     gv_ucFLAG &=~(FLAG_MOVE_FWD | FLAG_MOVE_BACK)
#define   FLAG_MOVING_CHK     gv_ucFLAG & (FLAG_MOVE_FWD | FLAG_MOVE_BACK)

#define   MIN_SPEED           1

uint8_t   gv_ucFLAG = 0x00;
uint16_t  gv_tkFWD  = 0x00;
uint16_t  gv_tkBACK = 0x00;

uint16_t  gv_tkSTEP = MIN_SPEED;
uint16_t  gv_tnSTEP = MIN_SPEED;

void setup() 
{
  // put your setup code here, to run once:
  pinMode(PIN_EN, OUTPUT);
  pinMode(PIN_STEP, OUTPUT);
  pinMode(PIN_DIR, OUTPUT);

  pinMode(PIN_FWD, INPUT_PULLUP);
  pinMode(PIN_BACK, INPUT_PULLUP);

  pinMode(PIN_POT, INPUT);

#ifdef __DEBUG__
  Serial.begin(115200);
#endif
}

void loop() 
{
  gv_tnSTEP = MIN_SPEED + analogRead(PIN_POT) / 100;

  if (PIN_STEP_CHK)
  {
    PIN_STEP_SET;
  }

  if (FLAG_MOVING_CHK)
  {
    if (gv_tkSTEP > 0)
    {
      gv_tkSTEP--;
    }
    else
    {
      // make a step
      PIN_STEP_CLR;
      // reset step tick
      gv_tkSTEP = gv_tnSTEP;
    }
  }

  if (PIN_FWD_CHK)
  {
    // FWD button down
    if (gv_tkFWD < MAX_TICK)
    {
      gv_tkFWD++;
    }
  }
  else
  {
    // FWD button up
    if (gv_tkFWD > BTN_TICK)
    {
#ifdef __DEBUG__      
      Serial.println("FWD");
#endif    
      if (FLAG_MOVING_CHK)
      {
        // already moving, stop it
        DISABLE_MOTOR;
        FLAG_MOVING_CLR;
      }
      else
      {
        ENABLE_MOTOR;
        FLAG_MOVE_FWD_SET;
      }
    }
    gv_tkFWD = 0;
  }

  if (PIN_BACK_CHK)
  {
    // FWD button down
    if (gv_tkBACK < MAX_TICK)
    {
      gv_tkBACK++;
    }
  }
  else
  {
    // FWD button up
    if (gv_tkBACK > BTN_TICK)
    {
#ifdef __DEBUG__      
      Serial.println("BACK");
#endif       
      if (FLAG_MOVING_CHK)
      {
        // already moving, stop it
        DISABLE_MOTOR;
        FLAG_MOVING_CLR;
      }
      else
      {
        ENABLE_MOTOR;
        FLAG_MOVE_BACK_SET;
      }
    }
    gv_tkBACK = 0;
  }

  delayMicroseconds(SYS_TICK);
}